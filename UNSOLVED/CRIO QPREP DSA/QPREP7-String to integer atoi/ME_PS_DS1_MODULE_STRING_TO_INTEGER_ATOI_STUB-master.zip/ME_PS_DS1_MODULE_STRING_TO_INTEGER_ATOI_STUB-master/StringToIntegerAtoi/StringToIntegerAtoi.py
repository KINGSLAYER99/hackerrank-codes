# Implement your solution by completing the below function
def myAtoi(s):
    x = 0

    return x

if __name__ == '__main__':
    s = input()
    result = myAtoi(s)
    print(result)
    
