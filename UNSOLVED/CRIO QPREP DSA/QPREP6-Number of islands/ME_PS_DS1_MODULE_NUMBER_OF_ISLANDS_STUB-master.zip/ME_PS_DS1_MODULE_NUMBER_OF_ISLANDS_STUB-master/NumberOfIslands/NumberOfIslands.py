
# Implement your solution by completing the below function
def numIslands(grid):
    x = 0

    return x

if __name__ == '__main__':
    row = input().split()
    n = int(row[0])
    m = int(row[1])
    grid = []
    for i in range(n):
        r = input()
        grid.append(r)
    result = numIslands(grid)
    print(result)
