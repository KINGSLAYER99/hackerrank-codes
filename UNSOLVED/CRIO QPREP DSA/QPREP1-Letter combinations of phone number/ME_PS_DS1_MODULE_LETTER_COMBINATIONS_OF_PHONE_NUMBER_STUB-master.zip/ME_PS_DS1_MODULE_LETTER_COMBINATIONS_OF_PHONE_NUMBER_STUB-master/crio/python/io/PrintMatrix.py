def OneDMatrix(arr, s):
	for i in arr:
		print(i, end = s)

def SquareMatrix(arr):
	for i in arr:
		for j in i:
			print(j, end = " ")
		print()

def TwoDMatrix(arr):
	for i in arr:
		for j in i:
			print(j, end = " ")
		print()
		