def OneDMatrix():
	arr = input().split()
	return arr

def SquareMatrix(n):
	arr = [input().split() for i in range (n)]
	return arr

def TwoDMatrix(n):
	arr = [input().split() for i in range (n)]
	return arr
