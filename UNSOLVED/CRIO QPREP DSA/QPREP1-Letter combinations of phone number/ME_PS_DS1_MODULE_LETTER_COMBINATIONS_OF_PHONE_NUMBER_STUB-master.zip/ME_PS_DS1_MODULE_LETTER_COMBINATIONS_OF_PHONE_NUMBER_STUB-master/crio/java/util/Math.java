public class Math {

    public int square(int x) {
        return x * x;
    }
}
