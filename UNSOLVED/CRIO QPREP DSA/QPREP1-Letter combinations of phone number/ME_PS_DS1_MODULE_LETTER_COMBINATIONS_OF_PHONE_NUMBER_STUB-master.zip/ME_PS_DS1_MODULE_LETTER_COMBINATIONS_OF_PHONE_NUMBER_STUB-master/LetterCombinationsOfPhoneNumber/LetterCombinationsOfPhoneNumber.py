from crio.python.io import PrintMatrix

# Implement your solution by completing the below function
def letterCombinations(digits):
    res = []
    
    return res

if __name__ == '__main__':
    digits = input()
    result = letterCombinations(digits)
    PrintMatrix.OneDMatrix(result, " ")
