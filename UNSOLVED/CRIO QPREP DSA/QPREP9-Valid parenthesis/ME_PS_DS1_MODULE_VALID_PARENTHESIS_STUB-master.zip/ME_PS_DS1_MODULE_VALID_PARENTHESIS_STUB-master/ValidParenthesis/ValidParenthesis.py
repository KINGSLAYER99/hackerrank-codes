# Implement your solution by completing the below function
def isValid(s):
    res = 0

    return res

if __name__ == '__main__':
    s = input()
    result = isValid(s)
    if result == 1:
        print('true')
    else:
        print('false')
